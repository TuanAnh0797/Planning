// Global using directives cho .NET 8
// Các namespace được sử dụng xuyên suốt project

global using System;
global using System.Collections.Generic;
global using System.Linq;
global using System.Text;

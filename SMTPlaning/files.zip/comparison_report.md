# BÁO CÁO SO SÁNH: FA ExcelTool vs SMT Planning Input

## 1. TỔNG QUAN

| Tiêu chí | FA ExcelTool | SMT Planning Template | Ghi chú |
|----------|--------------|----------------------|---------|
| Số sheets | 62 sheets | 18 sheets | FA phức tạp hơn nhiều |
| Định dạng | .xlsm (có macro) | .xlsx | |
| Mục đích | Lập kế hoạch FA (Final Assembly) | Lập kế hoạch SMT | Cần mapping FA→SMT |

---

## 2. SO SÁNH CHI TIẾT TỪNG LOẠI DỮ LIỆU

### 2.1. ĐƠN HÀNG (Orders)

| FA ExcelTool (Sheet: Order) | SMT Planning | Trạng thái |
|----------------------------|--------------|------------|
| `LotCode` | `FAOrderId` | ✅ Có |
| `ItemCode` | `FAModelId` | ✅ Có |
| `Qty` | `Quantity` | ✅ Có |
| `EarliestStartDateTime` | `StartDate` | ✅ Có |
| `Order Due Date` | `DueDate` | ✅ Có |
| `LotPriority` | `Priority` | ✅ Có |
| `CustomerCode` | `CustomerNote` | ✅ Có |
| `AllocationMethod` | - | ⚠️ **THIẾU** (F=Forward, B=Backward) |
| `AllocationFlag` | - | ⚠️ **THIẾU** (Y/N) |
| `OrderMonth` | - | ⚠️ **THIẾU** |
| `Plant` | - | ⚠️ **THIẾU** |
| `Category Code` | - | ⚠️ **THIẾU** |
| `NoBatch` | - | ⚠️ **THIẾU** |

**→ Cần thêm:** AllocationMethod, AllocationFlag

---

### 2.2. CÔNG ĐOẠN (Process/Stages)

| FA ExcelTool (Sheet: Process) | SMT Planning (1_Stages) | Trạng thái |
|------------------------------|------------------------|------------|
| `ProcessCode` | `StageId` | ✅ Có |
| `ProcessName` | `StageName` | ✅ Có |
| `ProcessOrder` | `Order` | ✅ Có |
| `BottleNeck` | - | ⚠️ **THIẾU** (N/Y) |
| `ProcessParamCode` | - | ⚠️ **THIẾU** |

**Dữ liệu FA có 4 Process:**
- ASSY (Order: 200)
- FCT (Order: 100)
- QC (Order: 300)
- RF (Order: 400)

**→ Cần thêm:** BottleNeck flag

---

### 2.3. RESOURCE/LINES (Máy/Dây chuyền)

| FA ExcelTool (Sheet: Resource) | SMT Planning (2_Lines) | Trạng thái |
|-------------------------------|----------------------|------------|
| `ResourceCode` | `LineId` | ✅ Có |
| `ResourceName` | `LineName` | ✅ Có |
| `ResourceType` | - | ⚠️ **THIẾU** (M=Machine, P=Process) |
| `ResourcePriority` | - | ⚠️ **THIẾU** (1-100) |
| `ValidFlag(Proc)` | `IsActive` | ✅ Có |
| `ResourceQtyConstraint` | - | ⚠️ **THIẾU** |
| `OperationStartDateTime` | - | ⚠️ **THIẾU** |
| `OperationEndDateTime` | - | ⚠️ **THIẾU** |
| `DisplayOrder` | - | ⚠️ **THIẾU** |
| `ResourceGroupCode` | `Zone` | ✅ Có (tương đương) |
| - | `MaxFeederSlots` | ✅ Có (FA không có) |
| - | `PhysicalPosition` | ✅ Có (FA không có) |

**Dữ liệu FA có 47 Resources:**
- FCT01, FA01, FA02
- PSNV1-35 (35 máy SMT)
- PSJP1-5 (5 máy)
- QC

**→ Cần thêm:** ResourceType, ResourcePriority, ValidFlag riêng cho Print/Proc

---

### 2.4. NĂNG LỰC SẢN XUẤT (Item-Resource Capacity)

| FA ExcelTool (Sheet: ItemResourceCapacity) | SMT Planning (7_SMT_Routing) | Trạng thái |
|-------------------------------------------|------------------------------|------------|
| `ItemCode` | `SMTModelId` | ✅ Có |
| `ResourceCode` | (Line trong Routing) | ✅ Có |
| `CapacityValue` | `LeadtimeMinutesPerUnit` | ✅ Có (đơn vị khác) |
| `CapacityUnit` | - | ⚠️ **THIẾU** (s/p, p/h, etc.) |
| `ProductionRate` | - | ⚠️ **THIẾU** (%) |
| `WarmupTime` | `FixedSetupMinutes` | ✅ Có |
| `CoolDownTime` | - | ⚠️ **THIẾU** |
| `ValidStartDate` | - | ⚠️ **THIẾU** |
| `ValidEndDate` | - | ⚠️ **THIẾU** |
| `ProductionVer` | - | ⚠️ **THIẾU** |
| `ReqdResourceQty` | - | ⚠️ **THIẾU** |
| `SubResourceType` | - | ⚠️ **THIẾU** |
| `ResourcePriority` | - | ⚠️ **THIẾU** |
| `ResourceAssembly` | - | ⚠️ **THIẾU** |

**Dữ liệu FA:**
- CapacityValue = 20 (s/p = giây/sản phẩm)
- ProductionRate = 100 (%)

**→ Cần thêm:** CapacityUnit, ProductionRate, CoolDownTime, ValidDate range, ResourceAssembly

---

### 2.5. BOM/ITEM COMPOSITION

| FA ExcelTool (Sheet: ItemComposition) | SMT Planning (5_FA_To_SMT_BOM) | Trạng thái |
|--------------------------------------|------------------------------|------------|
| `CompleteItemCode` | `FAModelId` | ✅ Có |
| `ProcessCode` | `StageId` | ✅ Có |
| `ChildItemCode` | `SMTModelId` (input) | ✅ Có |
| `ItemCode` | `SMTModelId` (output) | ✅ Có |
| `ReqQty` | `QuantityPerFA` | ✅ Có |
| `WaitTime` | - | ⚠️ **THIẾU** |
| `RelativeWaitTime` | - | ⚠️ **THIẾU** |
| `WaitTimeMode` | - | ⚠️ **THIẾU** (M=Manual) |
| `LoadingMethod` | - | ⚠️ **THIẾU** (SS=?) |
| `ProcessOrder` | - | ⚠️ **THIẾU** |
| `ItemCompositionCode` | - | ⚠️ **THIẾU** |

**Dữ liệu FA có 6166 BOM records - Flow:**
```
CompleteItem (FG) 
  → Process (FCT) → ChildItem → ItemCode (Panel)
  → Process (ASSY) → ChildItem → ItemCode (Assembly)
  → Process (QC) → ChildItem → ItemCode (Final)
```

**→ Cần thêm:** WaitTime, WaitTimeMode, LoadingMethod, ProcessOrder trong BOM

---

### 2.6. CA LÀM VIỆC (Work Shift)

| FA ExcelTool (Sheet: WorkShift) | SMT Planning (11_WorkingCalendar) | Trạng thái |
|--------------------------------|----------------------------------|------------|
| `ShiftCode` | `ShiftName` | ✅ Có |
| `ShiftGroupCode` | - | ⚠️ **THIẾU** (SHIFT1-4) |
| `StartTime` | `StartTime` | ✅ Có |
| `EndTime` | `EndTime` | ✅ Có |

**Dữ liệu FA có 4 Shift Groups:**
- SHIFT1: 06:00-14:00 (Ca sáng, 4 segments)
- SHIFT2: 14:10-22:00 (Ca chiều, 4 segments)
- SHIFT3: 22:10-05:50 (Ca đêm, 4 segments)
- SHIFT4: 08:00-17:30 (Ca hành chính, 4 segments)

**→ Cần thêm:** ShiftGroupCode, hỗ trợ nhiều segments trong 1 ca

---

### 2.7. LỊCH LÀM VIỆC RESOURCE (Base Calendar)

| FA ExcelTool (Sheet: BaseCalendar) | SMT Planning | Trạng thái |
|-----------------------------------|--------------|------------|
| `ResourceCode` | - | ⚠️ **THIẾU SHEET RIÊNG** |
| `ShiftCode` | - | ⚠️ **THIẾU** |
| `StartDayofWeek` | `WorkingDays` | ✅ Có (khác format) |
| `EndDayofWeek` | `WorkingDays` | ✅ Có |
| `ResourceQty` | - | ⚠️ **THIẾU** |

**Dữ liệu FA:** Mỗi Resource có calendar riêng với nhiều shifts
- FA01: SHIFT1,2,3 từ MO-SA
- FA02: SHIFT1,2,3 từ MO-SU (làm cả CN)
- PSJP2-5: SHIFT4 từ MO-SU

**→ Cần thêm Sheet: ResourceCalendar (lịch làm việc theo từng Resource)**

---

### 2.8. NGÀY LÀM VIỆC (Working Calendar)

| FA ExcelTool (Sheet: WorkingCalendar) | SMT Planning (12_Holidays) | Trạng thái |
|--------------------------------------|---------------------------|------------|
| `Date` | `Date` | ✅ Có |
| `Flag` (0/1) | `IsWorkingDay` | ✅ Có (inverse logic) |

**Dữ liệu FA:** 61 ngày từ 2025/11/01, Flag=0 là nghỉ, Flag=1 là làm việc

**→ OK, chỉ cần đổi logic (FA: 1=làm việc, SMT: có trong Holidays = nghỉ)**

---

### 2.9. ITEM/SẢN PHẨM

| FA ExcelTool (Sheet: Item) | SMT Planning (6_SMT_Models) | Trạng thái |
|---------------------------|----------------------------|------------|
| `ItemCode` | `SMTModelId` | ✅ Có |
| `ItemName` | `SMTModelName` | ✅ Có |
| `ItemType` | - | ⚠️ **THIẾU** (I/M/P) |
| `ItemGroupCode` | `GroupId` | ✅ Có |
| `Points` | - | ⚠️ **THIẾU** |
| `Cavity` | - | ⚠️ **THIẾU** |
| `LotDivCount` | - | ⚠️ **THIẾU** |
| `LotBatchCount` | `BatchSize` | ✅ Có (tương đương) |
| `LotpriorityFlag` | - | ⚠️ **THIẾU** |
| `OrderDataFlag` | - | ⚠️ **THIẾU** |
| `ItemPriority` | - | ⚠️ **THIẾU** |
| `UnitPrice` | - | ⚠️ **THIẾU** |
| `EstimatedDefectiveRate` | `ScrapRatePercent` | ✅ Có |
| `StockIncreaseMethod` | - | ⚠️ **THIẾU** |
| `StockDecreaseMethod` | - | ⚠️ **THIẾU** |
| `RoundupQty` | - | ⚠️ **THIẾU** |
| `InventoryConstraint` | - | ⚠️ **THIẾU** |

**Dữ liệu FA có 5367 Items:**
- ItemType I: 950 (Intermediate)
- ItemType M: 1581 (Material)
- ItemType P: 2836 (Product)

**→ Cần thêm:** ItemType, Cavity, LotDivCount, RoundupQty, InventoryConstraint

---

## 3. CÁC SHEET FA CÓ MÀ SMT THIẾU HOÀN TOÀN

| Sheet FA | Mục đích | Cần thiết cho SMT? |
|----------|----------|-------------------|
| `DetailCalendar` | Lịch chi tiết theo ngày-resource | ⚠️ CÓ THỂ CẦN |
| `NextResourceConstraint` | Ràng buộc Resource kế tiếp | ⚠️ CÓ THỂ CẦN |
| `ResourceSpec` | Spec của Resource | ❌ Không cần |
| `Idling` | Thời gian chờ giữa Process | ⚠️ CÓ THỂ CẦN |
| `IdlingTime` | Chi tiết Idling | ⚠️ CÓ THỂ CẦN |
| `BatchProduction` | Sản xuất theo batch | ✅ Đã có trong config |
| `IOStock` | Tồn kho I/O | ⚠️ CÓ THỂ CẦN |
| `LotStartConstraints_3` | Ràng buộc Lot Start | ⚠️ CÓ THỂ CẦN |
| `ScheduleParameter` | Tham số scheduling | ✅ Đã có trong 18_Config |
| `Outsourcing` | Gia công ngoài | ❌ Chưa cần |

---

## 4. TỔNG KẾT - CẦN BỔ SUNG VÀO SMT PLANNING

### 4.1. Bổ sung Fields vào các Sheet hiện có:

**Sheet 4_FA_Orders:**
- `AllocationMethod` (F/B)
- `AllocationFlag` (Y/N)
- `Plant`

**Sheet 1_Stages:**
- `BottleNeck` (Y/N)

**Sheet 2_Lines:**
- `ResourceType` (M/P)
- `ResourcePriority` (1-100)
- `DisplayOrder`

**Sheet 6_SMT_Models:**
- `ItemType` (I/M/P)
- `Cavity`
- `LotDivCount`
- `RoundupQty`

**Sheet 7_SMT_Routing:**
- `CapacityUnit` (s/p, p/h, etc.)
- `ProductionRate` (%)
- `CoolDownTime`
- `ValidStartDate`, `ValidEndDate`

**Sheet 5_FA_To_SMT_BOM:**
- `WaitTime`
- `WaitTimeMode`
- `LoadingMethod`

### 4.2. Thêm Sheets mới:

1. **ResourceCalendar** - Lịch làm việc theo Resource
2. **ShiftSegments** - Chi tiết segments trong mỗi ca
3. **IdlingConfig** - Thời gian chờ giữa Process
4. **IOStock** - Tồn kho đầu vào/ra
5. **NextResourceConstraint** - Ràng buộc chuyển Resource

---

## 5. ĐỀ XUẤT MAPPING DỮ LIỆU

```
FA Order.ItemCode → FA_To_SMT_BOM.FAModelId
                  → SMT_Models.SMTModelId (qua BOM)
                  → SMT_Routing (leadtime)
                  → ItemResourceCapacity (capacity per resource)
```

**Flow quy đổi:**
1. Đọc Order từ FA
2. Tra BOM để lấy danh sách SMT Items cần sản xuất
3. Tính số lượng: `FA_Qty × QuantityPerFA × (1 + ScrapRate%)`
4. Tra tồn kho và trừ đi
5. Tra Routing + Capacity để lập kế hoạch SMT

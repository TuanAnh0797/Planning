using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using SMTScheduler.Models;
using SMTScheduler.Services;

namespace SMTScheduler
{
    /// <summary>
    /// Benchmark Test - Đo hiệu năng OR-Tools với các quy mô dữ liệu khác nhau
    /// </summary>
    class BenchmarkTest
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.WriteLine("╔═══════════════════════════════════════════════════════════╗");
            Console.WriteLine("║         BENCHMARK TEST - OR-TOOLS CP-SAT                 ║");
            Console.WriteLine("║         Đo hiệu năng với các quy mô dữ liệu              ║");
            Console.WriteLine("╚═══════════════════════════════════════════════════════════╝");
            Console.WriteLine();

            // Các kịch bản test
            var scenarios = new List<BenchmarkScenario>
            {
                // Nhỏ
                new BenchmarkScenario("Nhỏ (S)", 10, 4, 3, false, 30),
                new BenchmarkScenario("Nhỏ + Lot Split", 10, 4, 3, true, 30),
                
                // Trung bình
                new BenchmarkScenario("Trung bình (M)", 30, 4, 5, false, 60),
                new BenchmarkScenario("Trung bình + Lot Split", 30, 4, 5, true, 60),
                
                // Lớn
                new BenchmarkScenario("Lớn (L)", 50, 4, 8, false, 120),
                new BenchmarkScenario("Lớn + Lot Split", 50, 4, 8, true, 120),
                
                // Rất lớn
                new BenchmarkScenario("Rất lớn (XL)", 100, 4, 10, false, 180),
                new BenchmarkScenario("Rất lớn + Lot Split", 100, 4, 10, true, 180),
                
                // Cực lớn (stress test)
                new BenchmarkScenario("Cực lớn (XXL)", 200, 5, 12, false, 300),
            };

            Console.WriteLine("═══════════════════════════════════════════════════════════════════════════════════════");
            Console.WriteLine($"{"Kịch bản",-25} {"Products",-10} {"Stages",-8} {"Lines",-8} {"LotSplit",-10} {"Biến (ước)",-12} {"Thời gian",-12} {"Kết quả",-12}");
            Console.WriteLine("═══════════════════════════════════════════════════════════════════════════════════════");

            var results = new List<BenchmarkResult>();

            foreach (var scenario in scenarios)
            {
                Console.Write($"{scenario.Name,-25} {scenario.NumProducts,-10} {scenario.NumStages,-8} {scenario.NumLines,-8} {(scenario.EnableLotSplit ? "Có" : "Không"),-10} ");

                var result = RunBenchmark(scenario);
                results.Add(result);

                string statusColor = result.IsSuccess ? "✓" : "✗";
                Console.WriteLine($"{result.EstimatedVariables,-12} {result.SolveTimeFormatted,-12} {statusColor} {result.Status,-10}");

                // Dừng nếu quá chậm
                if (result.SolveTimeMs > 300000) // > 5 phút
                {
                    Console.WriteLine("\n⚠️ Dừng benchmark - thời gian giải quá lâu!");
                    break;
                }
            }

            // In báo cáo tổng hợp
            PrintSummaryReport(results);

            Console.WriteLine("\nNhấn Enter để thoát...");
            Console.ReadLine();
        }

        /// <summary>
        /// Chạy benchmark cho một kịch bản
        /// </summary>
        static BenchmarkResult RunBenchmark(BenchmarkScenario scenario)
        {
            var result = new BenchmarkResult
            {
                Scenario = scenario
            };

            try
            {
                // Tạo dữ liệu test
                var (stages, lines, products, calendar) = GenerateTestData(scenario);

                // Ước tính số biến
                int batchMultiplier = scenario.EnableLotSplit ? 3 : 1;
                result.EstimatedVariables = scenario.NumProducts * scenario.NumStages * scenario.NumLines * batchMultiplier;

                // Tạo scheduler
                var scheduler = new SMTSchedulerService(stages, lines, products, DateTime.Today, calendar);
                
                // Cấu hình
                scheduler.EnableComponentGrouping = false;
                scheduler.EnableOperatorManagement = false;
                scheduler.EnableLotSplitting = scenario.EnableLotSplit;
                scheduler.EnableStageNaming = true;
                scheduler.EnableCustomRouting = true;
                scheduler.EnableStageTransferTime = true;

                // Cấu hình routing và lot splitting cho từng product
                foreach (var product in products)
                {
                    // Routing với leadtime ngẫu nhiên
                    var stageLeadtimes = new Dictionary<int, double>();
                    var random = new Random(product.Id.GetHashCode());
                    foreach (var stage in stages)
                    {
                        stageLeadtimes[stage.Id] = 0.3 + random.NextDouble() * 1.2; // 0.3 - 1.5 phút/sp
                    }
                    scheduler.RoutingManager.SetRoutingWithStageLeadtimes(product.Id, stageLeadtimes);

                    // Lot splitting nếu bật
                    if (scenario.EnableLotSplit && product.RequiredQuantity > 200)
                    {
                        product.SetStageLotSplitting(new Dictionary<int, int>
                        {
                            { 1, 150 },
                            { 2, 100 },
                            { 3, 120 },
                            { 4, 150 }
                        });
                    }
                }

                // Đo thời gian giải
                var stopwatch = Stopwatch.StartNew();
                var solveResult = scheduler.Solve(timeLimitSeconds: scenario.TimeLimitSeconds);
                stopwatch.Stop();

                result.SolveTimeMs = stopwatch.ElapsedMilliseconds;
                result.IsSuccess = solveResult.IsSuccess;
                result.Status = solveResult.Status;
                result.TaskCount = solveResult.Tasks?.Count ?? 0;
                result.MakespanMinutes = solveResult.MakespanMinutes;

                // Memory usage (approximate)
                result.MemoryMB = GC.GetTotalMemory(false) / (1024.0 * 1024.0);
            }
            catch (Exception ex)
            {
                result.IsSuccess = false;
                result.Status = $"ERROR: {ex.Message}";
            }

            return result;
        }

        /// <summary>
        /// Tạo dữ liệu test
        /// </summary>
        static (List<Stage>, List<Line>, List<Product>, WorkingCalendar) GenerateTestData(BenchmarkScenario scenario)
        {
            // Stages
            var stages = new List<Stage>();
            for (int i = 1; i <= scenario.NumStages; i++)
            {
                stages.Add(new Stage { Id = i, Name = $"Stage {i}", Order = i });
            }

            // Lines
            var lines = new List<Line>();
            for (int i = 1; i <= scenario.NumLines; i++)
            {
                var line = new Line($"L{i:D3}", $"Line {i}");
                foreach (var stage in stages)
                {
                    line.AddStageCapability(stage.Id, efficiency: 0.75 + (i % 3) * 0.08);
                }
                lines.Add(line);
            }

            // Products
            var products = new List<Product>();
            var random = new Random(42); // Fixed seed for reproducibility
            DateTime today = DateTime.Today;

            for (int i = 1; i <= scenario.NumProducts; i++)
            {
                int quantity = 100 + random.Next(400); // 100-500
                int deadlineDays = 3 + random.Next(10); // 3-12 days
                int priority = 1 + random.Next(3); // 1-3

                var product = new Product
                {
                    Id = $"P{i:D4}",
                    Name = $"Product {i}",
                    OrderQuantity = quantity,
                    StockQuantity = 0,
                    StartDate = today,
                    DueDate = today.AddDays(deadlineDays),
                    Priority = priority
                };

                // Stage naming
                var stageNames = new Dictionary<int, string>();
                for (int s = 1; s <= scenario.NumStages; s++)
                {
                    stageNames[s] = s == 1 ? product.Name : $"{product.Name}-S{s}";
                }
                product.SetStageNames(stageNames);

                products.Add(product);
            }

            // Calendar
            var calendar = new WorkingCalendar();
            calendar.WorkingDays = new List<DayOfWeek>
            {
                DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Wednesday,
                DayOfWeek.Thursday, DayOfWeek.Friday, DayOfWeek.Saturday
            };
            calendar.DefaultShift = new WorkShift("Ca ngày",
                new TimeSpan(8, 0, 0), new TimeSpan(17, 0, 0), 60);
            calendar.AddWeekendsAsHolidays(today, today.AddMonths(2));

            return (stages, lines, products, calendar);
        }

        /// <summary>
        /// In báo cáo tổng hợp
        /// </summary>
        static void PrintSummaryReport(List<BenchmarkResult> results)
        {
            Console.WriteLine();
            Console.WriteLine("╔═══════════════════════════════════════════════════════════╗");
            Console.WriteLine("║                    BÁO CÁO TỔNG HỢP                       ║");
            Console.WriteLine("╚═══════════════════════════════════════════════════════════╝");

            // Thống kê
            var successResults = results.Where(r => r.IsSuccess).ToList();
            var failedResults = results.Where(r => !r.IsSuccess).ToList();

            Console.WriteLine($"\n📊 THỐNG KÊ:");
            Console.WriteLine($"   Tổng số kịch bản: {results.Count}");
            Console.WriteLine($"   Thành công: {successResults.Count}");
            Console.WriteLine($"   Thất bại: {failedResults.Count}");

            if (successResults.Any())
            {
                Console.WriteLine($"\n⏱️ THỜI GIAN GIẢI (kịch bản thành công):");
                Console.WriteLine($"   Nhanh nhất: {successResults.Min(r => r.SolveTimeMs):N0} ms ({successResults.First(r => r.SolveTimeMs == successResults.Min(x => x.SolveTimeMs)).Scenario.Name})");
                Console.WriteLine($"   Chậm nhất: {successResults.Max(r => r.SolveTimeMs):N0} ms ({successResults.First(r => r.SolveTimeMs == successResults.Max(x => x.SolveTimeMs)).Scenario.Name})");
                Console.WriteLine($"   Trung bình: {successResults.Average(r => r.SolveTimeMs):N0} ms");
            }

            // Phân tích giới hạn
            Console.WriteLine($"\n🎯 PHÂN TÍCH GIỚI HẠN:");
            
            var lastSuccess = successResults.LastOrDefault();
            var firstFail = failedResults.FirstOrDefault();

            if (lastSuccess != null)
            {
                Console.WriteLine($"   ✓ Quy mô lớn nhất giải được:");
                Console.WriteLine($"     - {lastSuccess.Scenario.NumProducts} products × {lastSuccess.Scenario.NumStages} stages × {lastSuccess.Scenario.NumLines} lines");
                Console.WriteLine($"     - Lot Splitting: {(lastSuccess.Scenario.EnableLotSplit ? "Có" : "Không")}");
                Console.WriteLine($"     - Thời gian: {lastSuccess.SolveTimeFormatted}");
                Console.WriteLine($"     - Số biến ước tính: {lastSuccess.EstimatedVariables:N0}");
            }

            if (firstFail != null)
            {
                Console.WriteLine($"\n   ✗ Quy mô đầu tiên không giải được:");
                Console.WriteLine($"     - {firstFail.Scenario.NumProducts} products × {firstFail.Scenario.NumStages} stages × {firstFail.Scenario.NumLines} lines");
                Console.WriteLine($"     - Lý do: {firstFail.Status}");
            }

            // Khuyến nghị
            Console.WriteLine($"\n💡 KHUYẾN NGHỊ:");
            if (lastSuccess != null)
            {
                if (lastSuccess.Scenario.NumProducts >= 100)
                {
                    Console.WriteLine("   ✓ Hệ thống có thể xử lý quy mô LỚN (100+ products)");
                    Console.WriteLine("   ✓ Phù hợp cho lập kế hoạch tuần/tháng");
                }
                else if (lastSuccess.Scenario.NumProducts >= 50)
                {
                    Console.WriteLine("   ✓ Hệ thống xử lý tốt quy mô TRUNG BÌNH (50+ products)");
                    Console.WriteLine("   ✓ Phù hợp cho lập kế hoạch tuần");
                }
                else
                {
                    Console.WriteLine("   ⚠ Hệ thống phù hợp cho quy mô NHỎ");
                    Console.WriteLine("   → Cân nhắc tăng Time Limit hoặc giảm Lot Splitting");
                }

                if (lastSuccess.Scenario.EnableLotSplit)
                {
                    Console.WriteLine("   ✓ Lot Splitting không ảnh hưởng nhiều đến hiệu năng");
                }
            }

            // Bảng tham khảo
            Console.WriteLine($"\n📋 BẢNG THAM KHẢO THỜI GIAN:");
            Console.WriteLine("   ┌──────────────┬──────────┬─────────┬───────────┬─────────────┐");
            Console.WriteLine("   │ Quy mô       │ Products │ Lines   │ Time Limit│ Kết quả     │");
            Console.WriteLine("   ├──────────────┼──────────┼─────────┼───────────┼─────────────┤");
            Console.WriteLine("   │ Nhỏ (S)      │ 10-20    │ 3-5     │ 30s       │ < 5 giây    │");
            Console.WriteLine("   │ Trung bình   │ 30-50    │ 5-8     │ 60s       │ < 30 giây   │");
            Console.WriteLine("   │ Lớn (L)      │ 50-100   │ 8-10    │ 120s      │ < 2 phút    │");
            Console.WriteLine("   │ Rất lớn (XL) │ 100-200  │ 10-15   │ 300s      │ < 5 phút    │");
            Console.WriteLine("   │ Cực lớn      │ 200+     │ 15+     │ 600s+     │ Không chắc  │");
            Console.WriteLine("   └──────────────┴──────────┴─────────┴───────────┴─────────────┘");
        }
    }

    /// <summary>
    /// Kịch bản benchmark
    /// </summary>
    class BenchmarkScenario
    {
        public string Name { get; set; }
        public int NumProducts { get; set; }
        public int NumStages { get; set; }
        public int NumLines { get; set; }
        public bool EnableLotSplit { get; set; }
        public int TimeLimitSeconds { get; set; }

        public BenchmarkScenario(string name, int products, int stages, int lines, bool lotSplit, int timeLimit)
        {
            Name = name;
            NumProducts = products;
            NumStages = stages;
            NumLines = lines;
            EnableLotSplit = lotSplit;
            TimeLimitSeconds = timeLimit;
        }
    }

    /// <summary>
    /// Kết quả benchmark
    /// </summary>
    class BenchmarkResult
    {
        public BenchmarkScenario Scenario { get; set; }
        public long SolveTimeMs { get; set; }
        public bool IsSuccess { get; set; }
        public string Status { get; set; }
        public int TaskCount { get; set; }
        public long MakespanMinutes { get; set; }
        public int EstimatedVariables { get; set; }
        public double MemoryMB { get; set; }

        public string SolveTimeFormatted
        {
            get
            {
                if (SolveTimeMs < 1000)
                    return $"{SolveTimeMs} ms";
                else if (SolveTimeMs < 60000)
                    return $"{SolveTimeMs / 1000.0:F1} s";
                else
                    return $"{SolveTimeMs / 60000.0:F1} phút";
            }
        }
    }
}

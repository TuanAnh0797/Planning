using System;
using System.Collections.Generic;
using SMTScheduler.Models;
using SMTScheduler.Services;

namespace SMTScheduler
{
    /// <summary>
    /// Demo đơn giản - Chỉ có Stage, Line, Product với Stage Naming
    /// KHÔNG có: Component Grouping, Operator
    /// </summary>
    public class SimpleDemo
    {
        public static void Run()
        {
            Console.WriteLine("═══════════════════════════════════════════════════════════════");
            Console.WriteLine("     DEMO ĐƠN GIẢN - SMT SCHEDULER                             ");
            Console.WriteLine("     Với Stage Naming (Model đổi tên qua công đoạn)            ");
            Console.WriteLine("═══════════════════════════════════════════════════════════════");
            Console.WriteLine();

            // ═══════════════════════════════════════════════════════════════
            // 1. CÔNG ĐOẠN - 4 công đoạn chuẩn SMT
            // ═══════════════════════════════════════════════════════════════
            var stages = new List<Stage>
            {
                new Stage { Id = 1, Name = "Solder Paste", Order = 1 },
                new Stage { Id = 2, Name = "Pick & Place", Order = 2 },
                new Stage { Id = 3, Name = "Reflow", Order = 3 },
                new Stage { Id = 4, Name = "AOI", Order = 4 }
            };

            Console.WriteLine("--- CÔNG ĐOẠN ---");
            foreach (var s in stages)
            {
                Console.WriteLine($"  CĐ{s.Order}: {s.Name}");
            }

            // ═══════════════════════════════════════════════════════════════
            // 2. LINES - 3 dây chuyền
            // ═══════════════════════════════════════════════════════════════
            var lines = new List<Line>();

            var line1 = new Line("L001", "Line 1 - Samsung");
            line1.AddStageCapability(1, efficiency: 0.90);
            line1.AddStageCapability(2, efficiency: 0.85);
            line1.AddStageCapability(3, efficiency: 0.95);
            line1.AddStageCapability(4, efficiency: 0.90);
            lines.Add(line1);

            var line2 = new Line("L002", "Line 2 - Juki");
            line2.AddStageCapability(1, efficiency: 0.85);
            line2.AddStageCapability(2, efficiency: 0.80);
            line2.AddStageCapability(3, efficiency: 0.90);
            line2.AddStageCapability(4, efficiency: 0.85);
            lines.Add(line2);

            var line3 = new Line("L003", "Line 3 - Yamaha");
            line3.AddStageCapability(1, efficiency: 0.80);
            line3.AddStageCapability(2, efficiency: 0.90);
            line3.AddStageCapability(3, efficiency: 0.85);
            line3.AddStageCapability(4, efficiency: 0.80);
            lines.Add(line3);

            Console.WriteLine("\n--- LINES ---");
            foreach (var l in lines)
            {
                Console.WriteLine($"  {l.Name}");
            }

            // ═══════════════════════════════════════════════════════════════
            // 3. SẢN PHẨM - với Stage Naming
            //    Model đổi tên qua công đoạn: A → A2 → A3 → A4
            // ═══════════════════════════════════════════════════════════════
            DateTime today = DateTime.Today;
            var products = new List<Product>();

            // ─────────────────────────────────────────────────────────────
            // Model A
            // Tên qua công đoạn: A → A2 → A3 → A4
            // ─────────────────────────────────────────────────────────────
            var modelA = new Product
            {
                Id = "A",
                Name = "A",
                OrderQuantity = 500,
                StockQuantity = 0,
                StartDate = today,
                DueDate = today.AddDays(3),
                Priority = 1
            };
            // *** KHAI BÁO TÊN MODEL QUA TỪNG CÔNG ĐOẠN ***
            modelA.SetStageNames(new Dictionary<int, string>
            {
                { 1, "A" },   // Công đoạn 1: A
                { 2, "A2" },  // Công đoạn 2: A2
                { 3, "A3" },  // Công đoạn 3: A3
                { 4, "A4" }   // Công đoạn 4: A4
            });
            products.Add(modelA);

            // ─────────────────────────────────────────────────────────────
            // Model B
            // Tên qua công đoạn: B → B2 → B3 → B4
            // ─────────────────────────────────────────────────────────────
            var modelB = new Product
            {
                Id = "B",
                Name = "B",
                OrderQuantity = 300,
                StockQuantity = 0,
                StartDate = today,
                DueDate = today.AddDays(4),
                Priority = 2
            };
            modelB.SetStageNames(new Dictionary<int, string>
            {
                { 1, "B" },
                { 2, "B2" },
                { 3, "B3" },
                { 4, "B4" }
            });
            products.Add(modelB);

            // ─────────────────────────────────────────────────────────────
            // Model C
            // Dùng Pattern tự động: C → C-2 → C-3 → C-4
            // ─────────────────────────────────────────────────────────────
            var modelC = new Product
            {
                Id = "C",
                Name = "C",
                OrderQuantity = 400,
                StockQuantity = 0,
                StartDate = today,
                DueDate = today.AddDays(4),
                Priority = 2
            };
            // *** DÙNG PATTERN TỰ ĐỘNG TẠO TÊN ***
            // {Name} = tên gốc, {StageOrder} = số thứ tự công đoạn
            modelC.StageNamePattern = "{Name}-{StageOrder}";
            // Kết quả: C-1, C-2, C-3, C-4
            products.Add(modelC);

            // ─────────────────────────────────────────────────────────────
            // Model D (chỉ 3 công đoạn, bỏ AOI)
            // Tên qua công đoạn: D → D2 → D3
            // ─────────────────────────────────────────────────────────────
            var modelD = new Product
            {
                Id = "D",
                Name = "D",
                OrderQuantity = 350,
                StockQuantity = 0,
                StartDate = today,
                DueDate = today.AddDays(5),
                Priority = 3
            };
            modelD.SetStageNames(new Dictionary<int, string>
            {
                { 1, "D" },
                { 2, "D2" },
                { 3, "D3" }
                // Không có công đoạn 4 (AOI)
            });
            products.Add(modelD);

            // ─────────────────────────────────────────────────────────────
            // Model E
            // Tên qua công đoạn: E → E2 → E3 → E4
            // ─────────────────────────────────────────────────────────────
            var modelE = new Product
            {
                Id = "E",
                Name = "E",
                OrderQuantity = 250,
                StockQuantity = 0,
                StartDate = today,
                DueDate = today.AddDays(5),
                Priority = 3
            };
            modelE.SetStageNames(new Dictionary<int, string>
            {
                { 1, "E" },
                { 2, "E2" },
                { 3, "E3" },
                { 4, "E4" }
            });
            products.Add(modelE);

            // Hiển thị sản phẩm với Stage Naming
            Console.WriteLine("\n--- SẢN PHẨM VỚI STAGE NAMING ---");
            foreach (var p in products)
            {
                Console.WriteLine($"  {p.Name}: {p.RequiredQuantity} sp, Deadline: {p.DueDate:dd/MM/yyyy}");
                
                // Hiển thị tên qua từng công đoạn
                Console.Write("    Tên qua CĐ: ");
                for (int stageOrder = 1; stageOrder <= 4; stageOrder++)
                {
                    var stage = stages.Find(s => s.Order == stageOrder);
                    if (stage != null)
                    {
                        string nameAtStage = p.GetNameAtStage(stage.Id, stageOrder);
                        Console.Write($"CĐ{stageOrder}={nameAtStage}");
                        if (stageOrder < 4) Console.Write(" → ");
                    }
                }
                Console.WriteLine();
            }

            // ═══════════════════════════════════════════════════════════════
            // 4. LỊCH LÀM VIỆC
            // ═══════════════════════════════════════════════════════════════
            var calendar = new WorkingCalendar();
            calendar.DefaultShift = new WorkShift("Ca ngày",
                startTime: new TimeSpan(8, 0, 0),
                endTime: new TimeSpan(17, 0, 0),
                breakMinutes: 60);

            Console.WriteLine($"\n--- LỊCH LÀM VIỆC ---");
            Console.WriteLine($"  Ca: {calendar.DefaultShift}");

            // ═══════════════════════════════════════════════════════════════
            // 5. TẠO SCHEDULER (Constructor đơn giản)
            // ═══════════════════════════════════════════════════════════════
            var scheduler = new SMTSchedulerService(
                stages, 
                lines, 
                products, 
                today, 
                calendar);

            // Cấu hình - TẮT hết các tính năng không cần
            scheduler.EnableComponentGrouping = false;  // TẮT
            scheduler.EnableOperatorManagement = false; // TẮT
            scheduler.UseManualGrouping = false;        // TẮT
            scheduler.EnableSuggestions = false;        // TẮT
            scheduler.EnableLotSplitting = false;       // TẮT

            // BẬT các tính năng cần
            scheduler.EnableStageNaming = true;         // BẬT Stage Naming
            scheduler.EnableCustomRouting = true;       // BẬT Custom Routing
            scheduler.EnableStageTransferTime = true;   // BẬT Stage Transfer Time

            // ═══════════════════════════════════════════════════════════════
            // 5b. CẤU HÌNH THỜI GIAN TRANSFER GIỮA CÔNG ĐOẠN
            // ═══════════════════════════════════════════════════════════════
            Console.WriteLine("\n--- THỜI GIAN TRANSFER GIỮA CÔNG ĐOẠN ---");
            var stageTransfer = scheduler.StageTransferMatrix;

            stageTransfer.AddTransfer(1, 2, 3, "Kiểm tra kem hàn");
            stageTransfer.AddTransfer(2, 3, 2, "Di chuyển");
            stageTransfer.AddTransfer(3, 4, 10, "Chờ nguội sau Reflow");

            Console.WriteLine("  CĐ1 → CĐ2: 3 phút");
            Console.WriteLine("  CĐ2 → CĐ3: 2 phút");
            Console.WriteLine("  CĐ3 → CĐ4: 10 phút (chờ nguội)");

            // ═══════════════════════════════════════════════════════════════
            // 6. CẤU HÌNH ROUTING VỚI LEADTIME RIÊNG CHO TỪNG CÔNG ĐOẠN
            // ═══════════════════════════════════════════════════════════════
            Console.WriteLine("\n--- ROUTING (Leadtime theo Model-Công đoạn) ---");
            var routingMgr = scheduler.RoutingManager;

            // Model A: Leadtime khác nhau cho từng công đoạn
            routingMgr.SetRoutingWithStageLeadtimes("A", new Dictionary<int, double>
            {
                { 1, 0.5 },  // Solder Paste: 0.5 phút/sp
                { 2, 1.2 },  // Pick & Place: 1.2 phút/sp
                { 3, 0.8 },  // Reflow: 0.8 phút/sp
                { 4, 0.3 }   // AOI: 0.3 phút/sp
            });
            Console.WriteLine("  A: CĐ1=0.5, CĐ2=1.2, CĐ3=0.8, CĐ4=0.3 ph/sp");

            // Model B
            routingMgr.SetRoutingWithStageLeadtimes("B", new Dictionary<int, double>
            {
                { 1, 0.4 },
                { 2, 0.9 },
                { 3, 0.6 },
                { 4, 0.25 }
            });
            Console.WriteLine("  B: CĐ1=0.4, CĐ2=0.9, CĐ3=0.6, CĐ4=0.25 ph/sp");

            // Model C
            routingMgr.SetRoutingWithStageLeadtimes("C", new Dictionary<int, double>
            {
                { 1, 0.6 },
                { 2, 1.5 },
                { 3, 0.9 },
                { 4, 0.4 }
            });
            Console.WriteLine("  C: CĐ1=0.6, CĐ2=1.5, CĐ3=0.9, CĐ4=0.4 ph/sp");

            // Model D: Chỉ 3 công đoạn (bỏ AOI)
            routingMgr.SetRoutingWithStageLeadtimes("D", new Dictionary<int, double>
            {
                { 1, 0.3 },
                { 2, 0.7 },
                { 3, 0.5 }
            });
            Console.WriteLine("  D: CĐ1=0.3, CĐ2=0.7, CĐ3=0.5 ph/sp [Bỏ AOI]");

            // Model E
            routingMgr.SetRoutingWithStageLeadtimes("E", new Dictionary<int, double>
            {
                { 1, 0.35 },
                { 2, 0.85 },
                { 3, 0.55 },
                { 4, 0.2 }
            });
            Console.WriteLine("  E: CĐ1=0.35, CĐ2=0.85, CĐ3=0.55, CĐ4=0.2 ph/sp");

            // ═══════════════════════════════════════════════════════════════
            // 7. GIẢI
            // ═══════════════════════════════════════════════════════════════
            Console.WriteLine("\n═══════════════════════════════════════════════════════════════");
            Console.WriteLine("                      ĐANG GIẢI...                             ");
            Console.WriteLine("═══════════════════════════════════════════════════════════════");

            var result = scheduler.Solve(timeLimitSeconds: 30);

            // ═══════════════════════════════════════════════════════════════
            // 8. HIỂN THỊ KẾT QUẢ
            // ═══════════════════════════════════════════════════════════════
            Console.WriteLine($"\n  Status: {result.Status}");
            Console.WriteLine($"  Thời gian giải: {result.SolveTimeMs} ms");

            if (result.IsSuccess)
            {
                Console.WriteLine($"  Makespan: {result.MakespanMinutes} phút ({result.MakespanMinutes / 60.0:F1} giờ)");

                // In lịch trình chi tiết
                Console.WriteLine(result.GetDetailedSchedule());

                // In lịch trình đơn giản
                Console.WriteLine(result.GetSimpleSchedule());
            }
            else
            {
                Console.WriteLine("\n  ❌ KHÔNG TÌM ĐƯỢC LỊCH TRÌNH!");
                foreach (var reason in result.FailureReasons)
                {
                    Console.WriteLine($"     - {reason}");
                }
            }

            Console.WriteLine("\n═══════════════════════════════════════════════════════════════");
            Console.WriteLine("                         KẾT THÚC DEMO                         ");
            Console.WriteLine("═══════════════════════════════════════════════════════════════");
        }
    }
}

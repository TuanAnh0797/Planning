using System;
using System.Collections.Generic;
using SMTScheduler.Models;
using SMTScheduler.Services;

namespace SMTScheduler
{
    /// <summary>
    /// Demo với dữ liệu QUÁNG TẢI để test Suggestion (OT, Tuyển người)
    /// </summary>
    public class OverloadDemo
    {
        public static void Run()
        {
            Console.WriteLine("═══════════════════════════════════════════════════════════════");
            Console.WriteLine("     DEMO: HỆ THỐNG GỢI Ý KHI QUÁ TẢI (OT / TUYỂN NGƯỜI)      ");
            Console.WriteLine("═══════════════════════════════════════════════════════════════");
            Console.WriteLine();

            // ═══════════════════════════════════════════════════════════════
            // 1. CÔNG ĐOẠN - 4 công đoạn chuẩn
            // ═══════════════════════════════════════════════════════════════
            var stages = new List<Stage>
            {
                new Stage { Id = 1, Name = "Solder Paste", Order = 1 },
                new Stage { Id = 2, Name = "Pick & Place", Order = 2 },
                new Stage { Id = 3, Name = "Reflow", Order = 3 },
                new Stage { Id = 4, Name = "AOI", Order = 4 }
            };

            // ═══════════════════════════════════════════════════════════════
            // 2. LINES - CHỈ 2 LINE (năng lực hạn chế)
            // ═══════════════════════════════════════════════════════════════
            var lines = new List<Line>();

            // Line 1: Hỗ trợ tất cả công đoạn
            var line1 = new Line("L001", "Line 1 - Samsung", maxFeederSlots: 100, workingHoursPerDay: 8);
            line1.AddStageCapability(1, efficiency: 0.85);
            line1.AddStageCapability(2, efficiency: 0.80);
            line1.AddStageCapability(3, efficiency: 0.90);
            line1.AddStageCapability(4, efficiency: 0.85);
            lines.Add(line1);

            // Line 2: Hỗ trợ tất cả công đoạn
            var line2 = new Line("L002", "Line 2 - Juki", maxFeederSlots: 80, workingHoursPerDay: 8);
            line2.AddStageCapability(1, efficiency: 0.80);
            line2.AddStageCapability(2, efficiency: 0.75);
            line2.AddStageCapability(3, efficiency: 0.85);
            line2.AddStageCapability(4, efficiency: 0.80);
            lines.Add(line2);

            Console.WriteLine("--- LINES (CHỈ 2 LINE - NĂNG LỰC HẠN CHẾ) ---");
            foreach (var line in lines)
            {
                Console.WriteLine($"  {line}");
            }

            // ═══════════════════════════════════════════════════════════════
            // 3. LINH KIỆN
            // ═══════════════════════════════════════════════════════════════
            var components = new List<Component>
            {
                new Component { Id = "R1", Name = "Điện trở 10K", FeederSlots = 1, ChangeoverTimeMinutes = 2 },
                new Component { Id = "R2", Name = "Điện trở 4.7K", FeederSlots = 1, ChangeoverTimeMinutes = 2 },
                new Component { Id = "C1", Name = "Tụ 100uF", FeederSlots = 2, ChangeoverTimeMinutes = 3 },
                new Component { Id = "C2", Name = "Tụ 10uF", FeederSlots = 2, ChangeoverTimeMinutes = 3 },
                new Component { Id = "IC1", Name = "STM32F103", FeederSlots = 3, ChangeoverTimeMinutes = 5 },
                new Component { Id = "IC2", Name = "ESP32", FeederSlots = 3, ChangeoverTimeMinutes = 5 },
                new Component { Id = "IC3", Name = "ATmega328", FeederSlots = 2, ChangeoverTimeMinutes = 4 },
                new Component { Id = "LED1", Name = "LED đỏ", FeederSlots = 1, ChangeoverTimeMinutes = 2 },
                new Component { Id = "LED2", Name = "LED xanh", FeederSlots = 1, ChangeoverTimeMinutes = 2 },
                new Component { Id = "CON1", Name = "USB-C", FeederSlots = 2, ChangeoverTimeMinutes = 4 }
            };

            // ═══════════════════════════════════════════════════════════════
            // 4. SẢN PHẨM - SỐ LƯỢNG LỚN, DEADLINE GẤP
            // ═══════════════════════════════════════════════════════════════
            DateTime today = DateTime.Today;
            var products = new List<Product>();

            // Tổng cộng: 3500 sản phẩm trong 5 ngày làm việc
            // Năng lực bình thường: ~2000-2400 sản phẩm (2 line × 8h × 5 ngày)
            // → THIẾU ~1000-1500 sản phẩm → Cần OT hoặc tuyển người

            // PCB-A: 800 sản phẩm, deadline 3 ngày (RẤT GẤP)
            products.Add(new Product
            {
                Id = "PCB-A",
                Name = "Board IoT Gateway",
                RequiredQuantity = 800,
                StartDate = today,
                DueDate = today.AddDays(3),
                Priority = 1,
                ComponentIds = new List<string> { "R1", "R2", "C1", "IC1", "LED1", "CON1" }
            });

            // PCB-B: 600 sản phẩm, deadline 4 ngày
            products.Add(new Product
            {
                Id = "PCB-B",
                Name = "Board Sensor Hub",
                RequiredQuantity = 600,
                StartDate = today,
                DueDate = today.AddDays(4),
                Priority = 2,
                ComponentIds = new List<string> { "R1", "C1", "C2", "IC2", "LED2" }
            });

            // PCB-C: 700 sản phẩm, deadline 4 ngày
            products.Add(new Product
            {
                Id = "PCB-C",
                Name = "Board Motor Driver",
                RequiredQuantity = 700,
                StartDate = today,
                DueDate = today.AddDays(4),
                Priority = 2,
                ComponentIds = new List<string> { "R2", "C2", "IC3", "CON1" }
            });

            // PCB-D: 500 sản phẩm, deadline 5 ngày
            products.Add(new Product
            {
                Id = "PCB-D",
                Name = "Board Power Supply",
                RequiredQuantity = 500,
                StartDate = today,
                DueDate = today.AddDays(5),
                Priority = 3,
                ComponentIds = new List<string> { "R1", "R2", "C1", "C2", "LED1" }
            });

            // PCB-E: 900 sản phẩm, deadline 5 ngày (SỐ LƯỢNG LỚN NHẤT)
            products.Add(new Product
            {
                Id = "PCB-E",
                Name = "Board LED Controller",
                RequiredQuantity = 900,
                StartDate = today,
                DueDate = today.AddDays(5),
                Priority = 3,
                ComponentIds = new List<string> { "R1", "IC1", "LED1", "LED2", "CON1" }
            });

            Console.WriteLine("\n--- SẢN PHẨM (TỔNG 3500 SP TRONG 5 NGÀY) ---");
            int totalQty = 0;
            foreach (var p in products)
            {
                Console.WriteLine($"  {p.Name}: {p.RequiredQuantity} sp, Deadline: {p.DueDate:dd/MM/yyyy} ({(p.DueDate - today).Days} ngày)");
                totalQty += p.RequiredQuantity;
            }
            Console.WriteLine($"  ───────────────────────────────────");
            Console.WriteLine($"  TỔNG: {totalQty} sản phẩm");

            // ═══════════════════════════════════════════════════════════════
            // 5. LỊCH LÀM VIỆC - CHỈ 8 TIẾNG/NGÀY, KHÔNG OT
            // ═══════════════════════════════════════════════════════════════
            var calendar = new WorkingCalendar();
            calendar.WorkingDays = new List<DayOfWeek>
            {
                DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Wednesday,
                DayOfWeek.Thursday, DayOfWeek.Friday
            };
            calendar.DefaultShift = new WorkShift("Ca ngày",
                startTime: new TimeSpan(8, 0, 0),
                endTime: new TimeSpan(17, 0, 0),
                breakMinutes: 60);  // 8 tiếng thực tế

            // Thêm weekend là ngày nghỉ
            calendar.AddWeekendsAsHolidays(today, today.AddMonths(1));

            Console.WriteLine("\n--- LỊCH LÀM VIỆC ---");
            Console.WriteLine($"  Ca làm việc: {calendar.DefaultShift}");
            Console.WriteLine($"  Ngày làm việc: Thứ 2 - Thứ 6");
            Console.WriteLine($"  Giờ thực tế/ngày: {calendar.DefaultShift.TotalWorkingMinutes / 60.0:F1} tiếng");

            // ═══════════════════════════════════════════════════════════════
            // 6. OPERATORS - ÍT NGƯỜI, KỸ NĂNG HẠN CHẾ
            // ═══════════════════════════════════════════════════════════════
            var operators = new List<Operator>();

            // Chỉ có 3 người cho 2 line
            var op1 = new Operator("OP001", "Nguyễn Văn A");
            op1.SetSkill(1, SkillLevel.Expert);      // Giỏi Solder
            op1.SetSkill(2, SkillLevel.Proficient);  // Khá P&P
            op1.AssignToLine("L001");
            operators.Add(op1);

            var op2 = new Operator("OP002", "Trần Thị B");
            op2.SetSkill(2, SkillLevel.Expert);      // Giỏi P&P
            op2.SetSkill(3, SkillLevel.Proficient);  // Khá Reflow
            op2.SetSkill(4, SkillLevel.Basic);       // Cơ bản AOI
            op2.AssignToLine("L001");
            operators.Add(op2);

            var op3 = new Operator("OP003", "Lê Văn C");
            op3.SetSkill(1, SkillLevel.Basic);       // Cơ bản Solder
            op3.SetSkill(2, SkillLevel.Training);    // Đang học P&P
            op3.SetSkill(3, SkillLevel.Proficient);  // Khá Reflow
            op3.SetSkill(4, SkillLevel.Expert);      // Giỏi AOI
            op3.AssignToLine("L002");
            operators.Add(op3);

            Console.WriteLine("\n--- OPERATORS (CHỈ 3 NGƯỜI) ---");
            foreach (var op in operators)
            {
                Console.WriteLine($"  {op.Name} ({op.AssignedLineId}):");
                foreach (var skill in op.Skills)
                {
                    var stageName = stages.Find(s => s.Id == skill.Key)?.Name ?? "?";
                    Console.WriteLine($"      {stageName}: {skill.Value.Level}");
                }
            }

            // ═══════════════════════════════════════════════════════════════
            // 7. TRANSFER TIME
            // ═══════════════════════════════════════════════════════════════
            var transferMatrix = new TransferTimeMatrix(defaultMinutes: 10);
            transferMatrix.AddBidirectionalTransfer("L001", "L002", 5);

            // ═══════════════════════════════════════════════════════════════
            // 8. TẠO SCHEDULER VÀ CẤU HÌNH
            // ═══════════════════════════════════════════════════════════════
            var scheduler = new SMTSchedulerService(
                stages, lines, products, components, operators,
                today, calendar, transferMatrix);

            // Cấu hình
            scheduler.EnableGrouping = true;
            scheduler.EnableTransferTime = true;
            scheduler.EnableLotSplitting = false;  // Tắt lot splitting để thấy rõ quá tải
            scheduler.EnablePriorityScheduling = true;
            scheduler.EnableCustomRouting = true;
            scheduler.EnableSuggestions = true;    // BẬT SUGGESTION
            scheduler.UseHardDeadlineConstraint = false;  // Cho phép trễ deadline

            // Cấu hình suggestion
            scheduler.SuggestionConfig = new SuggestionConfig
            {
                MaxOvertimeHoursPerDay = 4,           // Tối đa 4 tiếng OT/ngày
                OvertimeCostMultiplier = 1.5,         // Chi phí OT = 150%
                WeekendOvertimeCostMultiplier = 2.0,  // Chi phí OT cuối tuần = 200%
                HolidayOvertimeCostMultiplier = 3.0,  // Chi phí OT ngày lễ = 300%
                NewHireTrainingDays = 5,              // Thời gian đào tạo 5 ngày
                HiringLeadTimeDays = 7,               // Thời gian tuyển dụng 7 ngày
                BaseHourlyCost = 50000,               // 50,000 VND/giờ
                EnableOTSuggestions = true,
                EnableHiringSuggestions = true,
                EnableSkillUpgradeSuggestions = true
            };

            // Cấu hình routing với leadtime
            var routingMgr = scheduler.RoutingManager;
            routingMgr.DefaultLeadtimeMinutesPerUnit = 1.2;  // 1.2 phút/sản phẩm mặc định

            // PCB-A: Leadtime cao (phức tạp)
            var routingA = routingMgr.SetRouting("PCB-A", new List<int> { 1, 2, 3, 4 }, baseLeadtime: 1.5);
            routingA.ComplexityFactor = 1.2;

            // PCB-B: Leadtime trung bình
            routingMgr.SetRouting("PCB-B", new List<int> { 1, 2, 3, 4 }, baseLeadtime: 1.3);

            // PCB-C: Leadtime trung bình
            routingMgr.SetRouting("PCB-C", new List<int> { 1, 2, 3, 4 }, baseLeadtime: 1.2);

            // PCB-D: Đơn giản, chỉ 3 công đoạn
            routingMgr.SetSimpleRouting("PCB-D", 0.8, 1, 2, 3);

            // PCB-E: Leadtime cao
            routingMgr.SetRouting("PCB-E", new List<int> { 1, 2, 3, 4 }, baseLeadtime: 1.4);

            // ═══════════════════════════════════════════════════════════════
            // 9. PHÂN TÍCH NĂNG LỰC TRƯỚC KHI GIẢI
            // ═══════════════════════════════════════════════════════════════
            Console.WriteLine("\n═══════════════════════════════════════════════════════════════");
            Console.WriteLine("                    PHÂN TÍCH NĂNG LỰC                         ");
            Console.WriteLine("═══════════════════════════════════════════════════════════════");

            // Tính năng lực lý thuyết
            int workingDays = 5;
            int hoursPerDay = 8;
            int linesCount = 2;
            double avgLeadtime = 1.3;  // phút/sp trung bình
            double avgEfficiency = 0.82;

            double theoreticalCapacity = (workingDays * hoursPerDay * 60 * linesCount) / (avgLeadtime / avgEfficiency);
            double requiredCapacity = totalQty * 4;  // 4 công đoạn

            Console.WriteLine($"\n  Năng lực lý thuyết: {theoreticalCapacity:N0} task-units");
            Console.WriteLine($"  Yêu cầu:            {requiredCapacity:N0} task-units");
            Console.WriteLine($"  Tỷ lệ sử dụng:      {requiredCapacity / theoreticalCapacity * 100:F1}%");

            if (requiredCapacity > theoreticalCapacity)
            {
                double shortage = requiredCapacity - theoreticalCapacity;
                Console.WriteLine($"\n  ⚠️  CẢNH BÁO: THIẾU {shortage:N0} task-units ({shortage / requiredCapacity * 100:F1}%)");
                Console.WriteLine("      → Cần OT hoặc tuyển thêm người!");
            }

            // ═══════════════════════════════════════════════════════════════
            // 10. GIẢI VÀ HIỂN THỊ KẾT QUẢ
            // ═══════════════════════════════════════════════════════════════
            Console.WriteLine("\n═══════════════════════════════════════════════════════════════");
            Console.WriteLine("                      ĐANG GIẢI...                             ");
            Console.WriteLine("═══════════════════════════════════════════════════════════════");

            var result = scheduler.Solve(timeLimitSeconds: 60);

            Console.WriteLine($"\n  Status: {result.Status}");
            Console.WriteLine($"  Thời gian giải: {result.SolveTimeMs} ms");

            if (result.IsSuccess)
            {
                Console.WriteLine($"  Makespan: {result.MakespanMinutes} phút ({result.MakespanMinutes / 60.0:F1} giờ)");
                Console.WriteLine($"  Ngày hoàn thành dự kiến: {result.ExpectedCompletionDate:dd/MM/yyyy HH:mm}");
            }

            // Hiển thị cảnh báo
            if (result.Warnings.Any())
            {
                Console.WriteLine("\n--- CẢNH BÁO ---");
                foreach (var warning in result.Warnings)
                {
                    Console.WriteLine($"  ⚠️  {warning}");
                }
            }

            // Hiển thị deadline bị trễ
            if (result.MissedDeadlines.Any())
            {
                Console.WriteLine("\n--- DEADLINE BỊ TRỄ ---");
                foreach (var missed in result.MissedDeadlines)
                {
                    Console.WriteLine($"  ❌ {missed.ProductName}: Trễ {missed.DelayMinutes} phút ({missed.DelayMinutes / 60.0:F1} giờ)");
                    Console.WriteLine($"      Deadline: {missed.DueDate:dd/MM HH:mm} → Hoàn thành: {missed.ActualEndDate:dd/MM HH:mm}");
                }
            }

            // ═══════════════════════════════════════════════════════════════
            // 11. HIỂN THỊ GỢI Ý (PHẦN QUAN TRỌNG NHẤT)
            // ═══════════════════════════════════════════════════════════════
            if (result.SuggestionReport != null)
            {
                Console.WriteLine("\n═══════════════════════════════════════════════════════════════");
                Console.WriteLine("                    GỢI Ý CẢI THIỆN                            ");
                Console.WriteLine("═══════════════════════════════════════════════════════════════");

                var report = result.SuggestionReport;

                Console.WriteLine($"\n  Tình trạng: {report.Summary}");
                Console.WriteLine($"  Tổng thời gian thiếu: {report.TotalShortfallMinutes:N0} phút ({report.TotalShortfallMinutes / 60.0:F1} giờ)");

                if (report.Suggestions.Any())
                {
                    Console.WriteLine($"\n  Có {report.Suggestions.Count} gợi ý:");

                    int suggestionIndex = 1;
                    foreach (var suggestion in report.Suggestions.OrderByDescending(s => s.Priority))
                    {
                        Console.WriteLine($"\n  ┌─ GỢI Ý #{suggestionIndex} ─────────────────────────────────────────");
                        Console.WriteLine($"  │ Loại: {suggestion.Type}");
                        Console.WriteLine($"  │ Mô tả: {suggestion.Description}");
                        Console.WriteLine($"  │ Ưu tiên: {suggestion.Priority}");
                        Console.WriteLine($"  │ Thời gian thu được: {suggestion.TimeGainMinutes:N0} phút ({suggestion.TimeGainMinutes / 60.0:F1} giờ)");
                        Console.WriteLine($"  │ Chi phí ước tính: {suggestion.EstimatedCost:N0} VND");

                        if (!string.IsNullOrEmpty(suggestion.AffectedLineId))
                            Console.WriteLine($"  │ Line: {suggestion.AffectedLineId}");
                        if (!string.IsNullOrEmpty(suggestion.AffectedStageId))
                            Console.WriteLine($"  │ Công đoạn: {suggestion.AffectedStageId}");
                        if (!string.IsNullOrEmpty(suggestion.AffectedOperatorId))
                            Console.WriteLine($"  │ Nhân viên: {suggestion.AffectedOperatorId}");

                        Console.WriteLine($"  └───────────────────────────────────────────────────────");
                        suggestionIndex++;
                    }

                    // Tổng chi phí
                    Console.WriteLine($"\n  ─── TỔNG KẾT GỢI Ý ───");
                    Console.WriteLine($"  Tổng chi phí ước tính: {report.Suggestions.Sum(s => s.EstimatedCost):N0} VND");
                    Console.WriteLine($"  Tổng thời gian thu được: {report.Suggestions.Sum(s => s.TimeGainMinutes):N0} phút");
                }
                else
                {
                    Console.WriteLine("\n  Không có gợi ý cụ thể. Hệ thống đang hoạt động hiệu quả.");
                }
            }

            // ═══════════════════════════════════════════════════════════════
            // 12. HIỂN THỊ BOTTLENECK
            // ═══════════════════════════════════════════════════════════════
            if (result.CapacityAnalyses != null && result.CapacityAnalyses.Any())
            {
                Console.WriteLine("\n═══════════════════════════════════════════════════════════════");
                Console.WriteLine("                    PHÂN TÍCH BOTTLENECK                       ");
                Console.WriteLine("═══════════════════════════════════════════════════════════════");

                foreach (var analysis in result.CapacityAnalyses.OrderByDescending(a => a.UtilizationPercent))
                {
                    string status = analysis.IsBottleneck ? "🔴 BOTTLENECK" : "🟢 OK";
                    Console.WriteLine($"\n  {analysis.StageName}:");
                    Console.WriteLine($"      Tỷ lệ sử dụng: {analysis.UtilizationPercent:F1}% {status}");
                    Console.WriteLine($"      Năng lực: {analysis.AvailableCapacityMinutes:N0} phút");
                    Console.WriteLine($"      Yêu cầu: {analysis.RequiredCapacityMinutes:N0} phút");

                    if (analysis.IsBottleneck)
                    {
                        Console.WriteLine($"      Thiếu: {analysis.ShortfallMinutes:N0} phút ({analysis.ShortfallMinutes / 60.0:F1} giờ)");
                    }
                }
            }

            Console.WriteLine("\n═══════════════════════════════════════════════════════════════");
            Console.WriteLine("                         KẾT THÚC DEMO                         ");
            Console.WriteLine("═══════════════════════════════════════════════════════════════");
        }
    }
}

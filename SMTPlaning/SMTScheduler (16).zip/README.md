# SMT Production Scheduler

Hệ thống lập lịch sản xuất SMT sử dụng **OR-Tools CP-SAT Solver** trên **.NET 8**.

## 🚀 Tính năng

- **Flexible Job Shop Scheduling**: Line có thể làm một hoặc nhiều công đoạn
- **Stage Lot Splitting**: Chia batch riêng cho từng công đoạn với Pipeline
- **Transfer Time**: Thời gian chuyển giữa Line và giữa công đoạn
- **Custom Routing**: Mỗi model có routing và leadtime riêng
- **Stage Naming**: Model đổi tên qua từng công đoạn
- **Working Calendar**: Lịch làm việc với ngày nghỉ, ca làm việc
- **Priority Levels**: Ưu tiên theo deadline và mức độ quan trọng
- **Smart Suggestions**: Gợi ý OT, tuyển dụng khi thiếu năng lực

## 📋 Yêu cầu

- .NET 8.0 SDK
- OR-Tools 9.10+

## 🔧 Cài đặt

```bash
# Clone repo
git clone <repository-url>
cd SMTScheduler

# Restore packages
dotnet restore

# Build
dotnet build

# Run
dotnet run
```

## 🐳 Docker

```bash
# Build image
docker build -t smt-scheduler .

# Run container
docker run --rm smt-scheduler
```

## 📁 Cấu trúc Project

```
SMTScheduler/
├── Models/
│   ├── Product.cs          # Sản phẩm với Stage Naming, Lot Splitting
│   ├── Stage.cs             # Công đoạn sản xuất
│   ├── Line.cs              # Line sản xuất
│   ├── LotSplitting.cs      # Cấu hình chia batch
│   ├── TransferTime.cs      # Thời gian chuyển Line/Stage
│   ├── ProductRouting.cs    # Routing và Leadtime
│   ├── WorkingCalendar.cs   # Lịch làm việc
│   └── ScheduleResult.cs    # Kết quả lập lịch
├── Services/
│   ├── SMTSchedulerService.cs    # Core solver với OR-Tools
│   ├── SuggestionService.cs      # Gợi ý tối ưu
│   └── ComponentGroupingService.cs # Nhóm linh kiện
├── Program.cs               # Main demo
├── SimpleDemo.cs            # Demo đơn giản
├── OverloadDemo.cs          # Demo quá tải
├── BenchmarkTest.cs         # Test hiệu năng
└── SMTScheduler.csproj      # Project file .NET 8
```

## 📊 Ví dụ sử dụng

```csharp
// Tạo scheduler
var scheduler = new SMTSchedulerService(stages, lines, products, DateTime.Today, calendar);

// Bật tính năng
scheduler.EnableLotSplitting = true;
scheduler.EnableStageTransferTime = true;
scheduler.EnableCustomRouting = true;

// Cấu hình Stage Lot Splitting
modelA.SetStageLotSplitting(new Dictionary<int, int>
{
    { 1, 250 },  // CĐ1: batch 250 sp
    { 2, 100 },  // CĐ2: batch 100 sp (chia nhỏ vì P&P chậm)
    { 3, 200 },  // CĐ3: batch 200 sp
    { 4, 250 }   // CĐ4: batch 250 sp
}, minGapMinutes: 5);

// Giải và in kết quả
var result = scheduler.Solve(timeLimitSeconds: 60);
Console.WriteLine(result.GetDetailedSchedule());
```

## 📈 Benchmark

| Quy mô | Products | Stages | Lines | Thời gian |
|--------|----------|--------|-------|-----------|
| Nhỏ | 10 | 4 | 3 | < 1s |
| Trung bình | 30 | 4 | 5 | < 10s |
| Lớn | 50 | 4 | 8 | < 1 phút |
| Rất lớn | 100 | 4 | 10 | < 3 phút |

## 📝 License

MIT License

## 👤 Author

PSNV - Panasonic System Networks Vietnam
